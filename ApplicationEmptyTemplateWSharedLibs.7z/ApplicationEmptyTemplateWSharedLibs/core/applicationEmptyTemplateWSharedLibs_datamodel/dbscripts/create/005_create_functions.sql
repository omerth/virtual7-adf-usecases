SPOOL 005_create_functions.log


SPOOL OFF