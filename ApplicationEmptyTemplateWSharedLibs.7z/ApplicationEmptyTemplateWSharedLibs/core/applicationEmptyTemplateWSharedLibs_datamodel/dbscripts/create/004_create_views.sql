SPOOL 004_create_views.log


SPOOL OFF