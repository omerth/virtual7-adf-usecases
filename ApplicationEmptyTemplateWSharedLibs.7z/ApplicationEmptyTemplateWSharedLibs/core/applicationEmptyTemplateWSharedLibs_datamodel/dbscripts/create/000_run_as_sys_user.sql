@@001_create_tablespaces_and_users.sql;
exit