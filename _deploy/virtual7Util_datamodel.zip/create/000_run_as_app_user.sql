@@002_create_synonims.sql;
@@003_create_objects.sql;
@@004_create_views.sql;
@@005_create_functions.sql;
@@006_populate_data.sql;
