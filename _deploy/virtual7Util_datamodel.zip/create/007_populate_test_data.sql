SPOOL 007_populate_test_data.log

SET DEFINE OFF;

SET DEFINE ON;

SPOOL OFF;