SELECT 
  t.*
FROM
  EMPLOYEES_DETAIL_HIST2 t
WHERE t.EMPLOYEE_ID = 100
--AND t1.e = binary_double_infinity
